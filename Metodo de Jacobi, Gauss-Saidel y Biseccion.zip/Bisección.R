
#Metodo de Bisección:

# Paso1: Definir las funciones f1, f2, f3 que representan el sistema de ecuaciones 
f1 <- function(x, y, z) {
  return(3*x - y - z - 1)  # Evaluación de la primera ecuación 
}

f2 <- function(x, y, z) {
  return(-x + 3*y + z - 3)  # Evaluación de la segunda ecuación 
}

f3 <- function(x, y, z) {
  return(2*x + y + 4*z - 7)  # Evaluación de la tercera ecuación 
}

#Paso 2: Método de bisección para resolver el sistemas de ecuaciones 
bisection_method <- function(f1, f2, f3, a1, b1, a2, b2, a3, b3, tol = 1e-6, max_iter = 40) {
  iter <- 0 # Inicializa el contador de iteraciones.
  while (iter < max_iter) {
    # Paso 2.1: Calcular los valores medios de los intervalos
    x_mid <- (a1 + b1) / 2 # Calcular el valor medio del intervalo para x
    y_mid <- (a2 + b2) / 2 # Calcular el valor medio del intervalo para y
    z_mid <- (a3 + b3) / 2 # Calcular el valor medio del intervalo para z
    
    # Paso 2.3: Calcular los valores de las funciones en el punto medio (x_mid, y_mid, z_mid)
    f1_mid <- f1(x_mid, y_mid, z_mid)  # Evaluación de f1 en el punto medio
    f2_mid <- f2(x_mid, y_mid, z_mid)  # Evaluación de f2 en el punto medio
    f3_mid <- f3(x_mid, y_mid, z_mid)  # Evaluación de f3 en el punto medio
    
    #Paso 2.4: Imprimir los valores actuales en la iteración
    cat("\nIteración", iter + 1, ":\n")
    cat("Punto medio:\n")
    cat("x =", x_mid, "\n")
    cat("y =", y_mid, "\n")
    cat("z =", z_mid, "\n")
    cat("f1(x_mid, y_mid, z_mid) =", f1_mid, "\n")
    cat("f2(x_mid, y_mid, z_mid) =", f2_mid, "\n")
    cat("f3(x_mid, y_mid, z_mid) =", f3_mid, "\n")
    
    # Paso 3: Verificacion de la tolerancia para determinar si sea encontrado una solución
    if (abs(f1_mid) < tol && abs(f2_mid) < tol && abs(f3_mid) < tol) { 
      # Unifica el mensaje de solución encontrada
      cat("\n¡Solución encontrada con la tolerancia especificada en la iteración número:", iter + 1, "!\n")
      cat("Valores de la solución:\n")
      cat("x =", x_mid, "\n")
      cat("y =", y_mid, "\n")
      cat("z =", z_mid, "\n")
      return(list(x = x_mid, y = y_mid, z = z_mid))  # Devuelve la solución encontrada
    }
    
    # Paso 4: Actualizar los intervalos basados en el cambio de signo en las funciones
    if (f1_mid * f1(a1, a2, a3) < 0) {
      b1 <- x_mid  # Actualiza el intervalo para x si hay un cambio de signo en f1
    } else {
      a1 <- x_mid  # De lo contrario, ajusta el otro extremo del intervalo
    }
    
    if (f2_mid * f2(a1, a2, a3) < 0) {
      b2 <- y_mid  # Actualiza el intervalo para y si hay un cambio de signo en f2
    } else {
      a2 <- y_mid  # De lo contrario, ajusta el otro extremo del intervalo
    }
    
    if (f3_mid * f3(a1, a2, a3) < 0) {
      b3 <- z_mid  # Actualiza el intervalo para z si hay un cambio de signo en f3
    } else {
      a3 <- z_mid  # De lo contrario, ajusta el otro extremo del intervalo
    }
    
    #Paso 4.1: Incrementar el contador de iteraciones
    iter <- iter + 1 # Aumenta el número de iteraciones en 1
  }
  
  # Si se alcanza el número máximo de iteraciones sin convergencia, imprimir un mensaje
cat("\nNúmero máximo de iteraciones alcanzado:", max_iter, "- No se encontró una solución con la tolerancia especificada.\n")
  return(NULL) # Devuelve NULL si no se encuentra una solución en el número máximo de iteraciones
}

# Valores iniciales de los intervalos para cada variable
a1 <- 0
b1 <- 1
a2 <- 0
b2 <- 1
a3 <- 0
b3 <- 1

# Llamar al método de bisección
solucion <- bisection_method(f1, f2, f3, a1, b1, a2, b2, a3, b3)

# La solución ya se imprime dentro de la función, por lo que no es necesario imprimirla de nuevo aquí.